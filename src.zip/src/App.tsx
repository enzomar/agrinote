import React, { Suspense } from "react";
import { Redirect, Route } from "react-router-dom";
import {
  IonApp,
  IonRouterOutlet,
  IonSplitPane,
  IonMenu,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonList,
  IonItem,
  IonIcon,
  IonLabel,
  IonMenuButton,
  IonButtons,
  IonLoading,
} from "@ionic/react";
import { IonReactRouter } from "@ionic/react-router";
import {
  homeOutline,
  medicalOutline,
  leafOutline,
  cubeOutline,
  analyticsOutline,
} from "ionicons/icons";

// Lazy load components for better performance
const Home = React.lazy(() => import("./pages/Home"));
const Treatments = React.lazy(() => import("./pages/Treatments"));
const Fertilizations = React.lazy(() => import("./pages/Fertilizations"));
const Warehouse = React.lazy(() => import("./pages/Warehouse"));
const Reports = React.lazy(() => import("./pages/Reports"));

// Import all required Ionic CSS
import "@ionic/react/css/core.css";
import "@ionic/react/css/normalize.css";
import "@ionic/react/css/structure.css";
import "@ionic/react/css/typography.css";
import "@ionic/react/css/padding.css";
import "@ionic/react/css/float-elements.css";
import "@ionic/react/css/text-alignment.css";
import "@ionic/react/css/text-transformation.css";
import "@ionic/react/css/flex-utils.css";
import "@ionic/react/css/display.css";

// Define route configuration for better maintainability
interface RouteConfig {
  path: string;
  component: React.LazyExoticComponent<React.ComponentType<any>>;
  exact: boolean;
  icon: string;
  title: string;
}

const routes: RouteConfig[] = [
  {
    path: "/home",
    component: Home,
    exact: true,
    icon: homeOutline,
    title: "Home",
  },
  {
    path: "/treatments",
    component: Treatments,
    exact: true,
    icon: medicalOutline,
    title: "Treatments",
  },
  {
    path: "/fertilizations",
    component: Fertilizations,
    exact: true,
    icon: leafOutline,
    title: "Fertilizations",
  },
  {
    path: "/warehouse",
    component: Warehouse,
    exact: true,
    icon: cubeOutline,
    title: "Warehouse",
  },
  {
    path: "/reports",
    component: Reports,
    exact: true,
    icon: analyticsOutline,
    title: "Reports",
  },
];

// Loading fallback component
const LoadingFallback: React.FC = () => (
  <IonLoading isOpen={true} message="Loading..." />
);

// Side menu component
const SideMenu: React.FC = () => (
  <IonMenu contentId="main" type="overlay">
    <IonHeader>
      <IonToolbar color="primary">
        <IonTitle>Farm Management</IonTitle>
      </IonToolbar>
    </IonHeader>
    <IonContent>
      <IonList>
        {routes.map((route) => (
          <IonItem
            key={route.path}
            routerLink={route.path}
            routerDirection="none"
            lines="none"
          >
            <IonIcon icon={route.icon} slot="start" />
            <IonLabel>{route.title}</IonLabel>
          </IonItem>
        ))}
      </IonList>
    </IonContent>
  </IonMenu>
);

// Main App component
const App: React.FC = () => {
  return (
    <IonApp>
      <IonReactRouter>
        <IonSplitPane contentId="main">
          <SideMenu />
          <IonRouterOutlet id="main">
            <Suspense fallback={<LoadingFallback />}>
              {routes.map((route) => (
                <Route
                  key={route.path}
                  path={route.path}
                  component={route.component}
                  exact={route.exact}
                />
              ))}
              <Route exact path="/" render={() => <Redirect to="/home" />} />
              {/* 404 fallback route */}
              <Route render={() => <Redirect to="/home" />} />
            </Suspense>
          </IonRouterOutlet>
        </IonSplitPane>
      </IonReactRouter>
    </IonApp>
  );
};

export default App;